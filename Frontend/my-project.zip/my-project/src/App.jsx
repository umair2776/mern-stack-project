import React from 'react'
import Navbar from "./components/Navbar"
import Carousel from './components/Carousel'
import Product from './components/Product'
import Products from './components/Products'
import Conditioner from './components/Conditioner'
import Conditioners from './components/Conditioners'
import Sunsilk from './components/Sunsilk'
import Sunsilks from './components/Sunsilks'
import Footer from './components/Footer'
import { Route,Routes } from 'react-router-dom'
import Home from "./components/Home"
import Contact from './pages/Contact'
import Cosmatics from './pages/Cosmatics'
import MainNavbar from './components/MainNavbar'

const App = () => {
  return (
    <div>
      <MainNavbar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/cosmatics' element={<Cosmatics/>}/>

      </Routes>
    </div>
  )
}

export default App
