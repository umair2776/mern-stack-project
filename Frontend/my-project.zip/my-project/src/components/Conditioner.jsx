import React from 'react'

const Conditioner = () => {
  return (
    <div>
      <div>
        <h1 className='text-2xl mt-12 ms-4 font-semibold'>Conditioners ></h1>
      </div>
    </div>
  )
}

export default Conditioner
