import React from 'react'
import image1 from "../../New folder/1c.avif"
import image2 from "../../New folder/2c.avif"
import image3 from "../../New folder/3c.avif"
import image4 from "../../New folder/4c.avif"

const Conditioners = () => {
  return (
    <div className="flex gap-4 "> {/* Center the card */}
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image1} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 185ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 350</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image2} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 360ML 
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 650</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image3} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 250ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 500</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image4} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 300ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 550</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
  </div>
  )
}

export default Conditioners
