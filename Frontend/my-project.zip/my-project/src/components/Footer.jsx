import React from 'react'

const Footer = () => {
  return (
    <div className='container max-w-full max-h-full bg-gray-300 mt-2'>
      <div>
        <div className=''>
            <ul className='flex py-6 justify-around'>
                <div className='flex flex-col gap-2 mt-2'>
            <li className='font-bold cursor-pointer'>GET IN TOUCH</li>
            <ul className='flex flex-col gap-4'>
                <li className='cursor-pointer'>
                   +92 42 111178956
                </li>
                <li className='cursor-pointer'>
                  support@shop.com
                </li>
            </ul>
            </div>

            <div className='flex flex-col gap-4'>
            <li className='font-bold cursor-pointer'>INFORMATION</li>
            <ul className='flex flex-col gap-4'>
                <li className='cursor-pointer'>
                  Online Order Tracking
                </li>
                <li className='cursor-pointer'>
                  Snipping Policy
                </li>
                <li className='cursor-pointer'>
                  Returns & Exchange Policy
                </li>
                <li className='cursor-pointer'>
                  Discount Policy
                </li>
                <li className='cursor-pointer'>
                  Privacy Policy
                </li>
            </ul>
            </div>
            <div className='flex flex-col gap-2'>
            <li className='font-bold cursor-pointer'>About</li>
            <ul className='flex flex-col gap-4 '>
                <li className='cursor-pointer'>
                    Our Story
                </li>
                <li className='cursor-pointer'>
                Career@apna 
                </li>
                <li className='cursor-pointer'>
                   Contact us
                </li>
                <li className='cursor-pointer'>
                  Blogs
                </li>
                <li className='cursor-pointer'>
                 Download your App
                </li>
                <li className='cursor-pointer'>
                 Terms of Service
                </li>
                <li className='cursor-pointer'>
                 Store Locations
                </li>
                <li className='cursor-pointer'>
                 Join Franchise
                </li>
            </ul>
            </div>
            <div className='flex flex-col gap-2'>
            <li className='font-bold cursor-pointer'>Sign in And Sign Up</li>
           <p className='line-clamp-8 w-56 '>Subcribe to get special offers. free giveaways, and once-in-a lifetime deals</p>
         <div>
            <input type='email' name='email' placeholder='Enter your email' className='py-1 px-2 rounded-md'/>
            <button className='bg-blue-950 text-white ms-1 py-1 px-2 rounded-md'>Subcribe</button>
         </div>
            </div>


            </ul>
            
        </div>
      </div>
    </div>
  )
}

export default Footer
