import React from 'react'

const Product = () => {
  return (
    <>
    <div className=' text-center mt-4'>
      <h1 className='text-4xl font-semibold'>All Products Here</h1>
    </div>
    <div className=''>
        <h1 className='ms-4 text-2xl font-semibold'>Meclay Shampoo ></h1>
    </div>
    </>
  )
}

export default Product
