import React from 'react'
import Image from "../../New folder/1.avif"
import Image1 from "../../New folder/2.avif"
import Image2 from "../../New folder/3.avif"
import Image3 from "../../New folder/4.avif"


const Products = () => {
  return (
    <div className="flex gap-4 "> {/* Center the card */}
      <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
        {/* Image Section */}
        <div className="overflow-hidden rounded-md">
          <img src={Image} className="max-h-[250px] w-full object-cover" alt="Product Image" />
        </div>
        {/* Product Details */}
        <div className="mt-4">
          <h1 className=" text-center font-semibold">Meclay London</h1>
          <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
            Thick & Dense Shampoo 185ML
          </p>
          <h1 className="text-sm text-center font-bold mt-2">Rs. 331</h1>
          <p className=" text-center mt-2">74.3k sold | </p>
        </div>
      </div>
      <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
        {/* Image Section */}
        <div className="overflow-hidden rounded-md">
          <img src={Image1} className="max-h-[250px] w-full object-cover" alt="Product Image" />
        </div>
        {/* Product Details */}
        <div className="mt-4">
          <h1 className=" text-center font-semibold">Meclay London</h1>
          <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
            Thick & Dense Shampoo 360ML 
          </p>
          <h1 className="text-sm text-center font-bold mt-2">Rs. 631</h1>
          <p className=" text-center mt-2">74.3k sold | </p>
        </div>
      </div>
      <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
        {/* Image Section */}
        <div className="overflow-hidden rounded-md">
          <img src={Image2} className="max-h-[250px] w-full object-cover" alt="Product Image" />
        </div>
        {/* Product Details */}
        <div className="mt-4">
          <h1 className=" text-center font-semibold">Meclay London</h1>
          <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
            Thick & Dense Shampoo 250ML
          </p>
          <h1 className="text-sm text-center font-bold mt-2">Rs. 450</h1>
          <p className=" text-center mt-2">74.3k sold | </p>
        </div>
      </div>
      <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
        {/* Image Section */}
        <div className="overflow-hidden rounded-md">
          <img src={Image3} className="max-h-[250px] w-full object-cover" alt="Product Image" />
        </div>
        {/* Product Details */}
        <div className="mt-4">
          <h1 className=" text-center font-semibold">Meclay London</h1>
          <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
            Thick & Dense Shampoo 300ML
          </p>
          <h1 className="text-sm text-center font-bold mt-2">Rs. 500</h1>
          <p className=" text-center mt-2">74.3k sold | </p>
        </div>
      </div>
    </div>
  )
}

export default Products
