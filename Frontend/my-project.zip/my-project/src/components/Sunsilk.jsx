import React from 'react'

const Sunsilk = () => {
  return (
    <div className='text-2xl mt-12 ms-4 font-semibold '>
      <h1>Sunsilk Shampoo ></h1>
    </div>
  )
}

export default Sunsilk
