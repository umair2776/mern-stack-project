import React from 'react'
import image1 from "../../New folder (4)/1.jfif"
import image2 from "../../New folder (4)/2.jfif"
import image3 from "../../New folder (4)/3.jfif"
import image4 from "../../New folder (4)/4.jpeg"
import image5 from "../../New folder (4)/5.jpeg"
import image6 from "../../New folder (4)/6.jpeg"
import image7 from "../../New folder (4)/7.jpeg"
import image8 from "../../New folder (4)/8.jpeg"

import Footer from '../components/Footer'

const Cosmatics = () => {
  return (
    <>
    <div className="flex gap-4 mt-12"> {/* Center the card */}
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image1} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 185ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 350</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image2} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 360ML 
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 650</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image3} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 250ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 500</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image4} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 300ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 550</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
  </div>

  <div className="flex gap-4 mt-12"> {/* Center the card */}
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image5} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 185ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 350</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image6} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 360ML 
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 650</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image7} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 250ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 500</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
    <div className="bg-white w-fit hover:shadow-lg rounded-md p-4">
      {/* Image Section */}
      <div className="overflow-hidden rounded-md">
        <img src={image8} className="max-h-[250px] w-full object-cover" alt="Product Image" />
      </div>
      {/* Product Details */}
      <div className="mt-4">
        <h1 className=" text-center font-semibold">Meclay London</h1>
        <p className="text-pink-400 text-sm text-center break-words whitespace-normal">
          Thick & Dense Conditioner 300ML
        </p>
        <h1 className="text-sm text-center font-bold mt-2">Rs. 550</h1>
        <p className=" text-center mt-2">74.3k sold | </p>
      </div>
    </div>
  </div>
  <div className='mt-24'>
  <Footer/>
  </div>
  </>
  )
}

export default Cosmatics
